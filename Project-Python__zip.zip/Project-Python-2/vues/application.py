# -*- coding: utf-8 -*-
"""
Application - Fenêtre principale de l'application
"""

import os
from PIL import Image, ImageTk
import customtkinter as ctk
from controleurs.gestionnaire_donnees import GestionnaireDonnees
from vues.vue_connexion import VueConnexion
from vues.tableau_admin import TableauAdmin
from vues.tableau_enseignant import TableauEnseignant
from vues.tableau_etudiant import TableauEtudiant
from utilitaires.constantes import TAILLE_FENETRE, TAILLE_MIN, COULEURS


class Application(ctk.CTk):
    """
    Classe principale de l'application.
    
    Gère la navigation entre les différentes vues selon le rôle de l'utilisateur.
    """
    
    def __init__(self):
        """Initialise l'application principale."""
        super().__init__()
        
        # Configuration de la fenêtre
        self.title("Gestion des Emplois du Temps - Université")
        self.geometry(TAILLE_FENETRE)
        self.minsize(*TAILLE_MIN)
        
        # Configuration de l'icône
        try:
            chemin_icone = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "icon.png")
            if os.path.exists(chemin_icone):
                image_icone = Image.open(chemin_icone)
                photo_icone = ImageTk.PhotoImage(image_icone)
                self.wm_iconphoto(True, photo_icone)
                print("Icône de l'application chargée avec succès.")
        except Exception as e:
            print("Impossible de charger l'icône: " + str(e))
        
        # Thème CustomTkinter
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")
        
        # Initialiser le gestionnaire de données
        self.gestionnaire = GestionnaireDonnees()
        
        # Utilisateur connecté
        self.utilisateur_connecte = None
        
        # Conteneur principal
        self.conteneur = ctk.CTkFrame(self, fg_color=COULEURS["fond"])
        self.conteneur.pack(fill="both", expand=True)
        
        # Vue actuelle
        self.vue_actuelle = None
        
        # Afficher l'écran de connexion
        self.afficher_connexion()
    
    def afficher_connexion(self):
        """Affiche l'écran de connexion."""
        self.utilisateur_connecte = None
        self._changer_vue(VueConnexion(self.conteneur, self))
    
    def connecter_utilisateur(self, utilisateur):
        """
        Connecte un utilisateur et affiche le tableau de bord approprié.
        
        Args:
            utilisateur: Instance de Utilisateur
        """
        self.utilisateur_connecte = utilisateur
        
        if utilisateur.est_admin():
            self._changer_vue(TableauAdmin(self.conteneur, self))
        elif utilisateur.est_enseignant():
            self._changer_vue(TableauEnseignant(self.conteneur, self))
        elif utilisateur.est_etudiant():
            self._changer_vue(TableauEtudiant(self.conteneur, self))
    
    def deconnecter(self):
        """Déconnecte l'utilisateur et retourne à l'écran de connexion."""
        self.afficher_connexion()
    
    def _changer_vue(self, nouvelle_vue):
        """
        Change la vue affichée.
        
        Args:
            nouvelle_vue: Nouvelle vue à afficher
        """
        if self.vue_actuelle:
            self.vue_actuelle.destroy()
        self.vue_actuelle = nouvelle_vue
        self.vue_actuelle.pack(fill="both", expand=True)


def lancer_application():
    """Lance l'application."""
    app = Application()
    app.mainloop()


if __name__ == "__main__":
    lancer_application()
