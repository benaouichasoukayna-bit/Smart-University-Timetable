# -*- coding: utf-8 -*-
"""
DetecteurConflits - Détection des conflits dans l'emploi du temps
"""


class DetecteurConflits:
    """
    Classe pour détecter les conflits dans l'emploi du temps.
    """
    
    def __init__(self, gestionnaire_donnees):
        """
        Initialise le détecteur de conflits.
        """
        self.gestionnaire = gestionnaire_donnees
    
    def detecter_conflits_seance(self, seance, seances_existantes):
        """
        Détecte tous les conflits pour une séance donnée.
        Retourne une liste de conflits.
        """
        conflits = []
        
        for autre in seances_existantes:
            if seance.id == autre.id:
                continue
            
            if seance.jour != autre.jour or seance.creneau_id != autre.creneau_id:
                continue
            
            # Conflit de salle
            if seance.salle_id == autre.salle_id:
                conflits.append({
                    "type": "salle",
                    "seance_1": seance.id,
                    "seance_2": autre.id,
                    "message": "Conflit de salle: même salle utilisée"
                })
            
            # Conflit d'enseignant
            if seance.enseignant_id == autre.enseignant_id:
                conflits.append({
                    "type": "enseignant",
                    "seance_1": seance.id,
                    "seance_2": autre.id,
                    "message": "Conflit d'enseignant: même enseignant"
                })
            
            # Conflit de groupe
            if seance.groupe_id == autre.groupe_id:
                conflits.append({
                    "type": "groupe",
                    "seance_1": seance.id,
                    "seance_2": autre.id,
                    "message": "Conflit de groupe: même groupe"
                })
        
        return conflits
    
    def detecter_tous_conflits(self, seances=None):
        """
        Détecte tous les conflits dans l'emploi du temps.
        """
        if seances is None:
            seances = self.gestionnaire.charger_seances()
        
        tous_conflits = []
        seances_verifiees = set()
        
        for seance in seances:
            conflits = self.detecter_conflits_seance(seance, seances)
            for conflit in conflits:
                # Éviter les doublons
                cle = tuple(sorted([conflit["seance_1"], conflit["seance_2"]]))
                if cle not in seances_verifiees:
                    tous_conflits.append(conflit)
                    seances_verifiees.add(cle)
        
        return tous_conflits
    
    def salle_est_libre(self, salle_id, jour, creneau_id, seances=None):
        """
        Vérifie si une salle est libre à un créneau donné.
        """
        if seances is None:
            seances = self.gestionnaire.charger_seances()
        
        for seance in seances:
            if seance.salle_id == salle_id and seance.jour == jour and seance.creneau_id == creneau_id:
                return False
        return True
    
    def enseignant_est_libre(self, enseignant_id, jour, creneau_id, seances=None):
        """
        Vérifie si un enseignant est libre à un créneau donné.
        """
        if seances is None:
            seances = self.gestionnaire.charger_seances()
        
        # Vérifier les indisponibilités déclarées
        enseignant = self.gestionnaire.trouver_enseignant_par_id(enseignant_id)
        if enseignant and not enseignant.est_disponible(jour, creneau_id):
            return False
        
        # Vérifier les séances existantes
        for seance in seances:
            if seance.enseignant_id == enseignant_id and seance.jour == jour and seance.creneau_id == creneau_id:
                return False
        return True
    
    def groupe_est_libre(self, groupe_id, jour, creneau_id, seances=None):
        """
        Vérifie si un groupe est libre à un créneau donné.
        """
        if seances is None:
            seances = self.gestionnaire.charger_seances()
        
        for seance in seances:
            if seance.groupe_id == groupe_id and seance.jour == jour and seance.creneau_id == creneau_id:
                return False
        return True
