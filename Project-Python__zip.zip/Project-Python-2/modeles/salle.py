# -*- coding: utf-8 -*-
"""
Classe Salle - Représente une salle de cours
"""


class Salle:
    """
    Classe représentant une salle de cours.
    """
    
    TYPES_VALIDES = ["amphi", "td", "tp"]
    
    def __init__(self, id, nom, type_salle, capacite, equipements=None):
        """
        Initialise une nouvelle salle.
        """
        self.id = id
        self.nom = nom
        self.type = type_salle
        self.capacite = capacite
        self.equipements = equipements or []
    
    def peut_accueillir(self, nombre_etudiants):
        """Vérifie si la salle peut accueillir un nombre donné d'étudiants."""
        return self.capacite >= nombre_etudiants
    
    def a_equipement(self, equipement):
        """Vérifie si la salle possède un équipement spécifique."""
        return equipement in self.equipements
    
    def a_tous_equipements(self, equipements_requis):
        """Vérifie si la salle possède tous les équipements requis."""
        if not equipements_requis:
            return True
        for eq in equipements_requis:
            if eq not in self.equipements:
                return False
        return True
    
    def vers_dict(self):
        """Convertit la salle en dictionnaire."""
        return {
            "id": self.id,
            "nom": self.nom,
            "type": self.type,
            "capacite": self.capacite,
            "equipements": self.equipements
        }
    
    @classmethod
    def depuis_dict(cls, data):
        """Crée une salle à partir d'un dictionnaire."""
        return cls(
            id=data.get("id"),
            nom=data.get("nom"),
            type_salle=data.get("type"),
            capacite=data.get("capacite"),
            equipements=data.get("equipements", [])
        )
    
    def __repr__(self):
        return "Salle(id=" + str(self.id) + ", nom=" + str(self.nom) + ", type=" + str(self.type) + ")"
