# -*- coding: utf-8 -*-
"""
Classe Enseignant - Représente un enseignant
"""


class Enseignant:
    """
    Classe représentant un enseignant.
    """
    
    def __init__(self, id, utilisateur_id, specialisation, modules=None, indisponibilites=None):
        """
        Initialise un nouvel enseignant.
        """
        self.id = id
        self.utilisateur_id = utilisateur_id
        self.specialisation = specialisation
        self.modules = modules or []
        self.indisponibilites = indisponibilites or []
    
    def est_disponible(self, jour, creneau_id):
        """
        Vérifie si l'enseignant est disponible sur un créneau donné.
        """
        for indispo in self.indisponibilites:
            if indispo.get("jour") == jour and indispo.get("creneau_id") == creneau_id:
                return False
        return True
    
    def ajouter_indisponibilite(self, jour, creneau_id, motif=""):
        """
        Ajoute une indisponibilité pour l'enseignant.
        """
        self.indisponibilites.append({
            "jour": jour,
            "creneau_id": creneau_id,
            "motif": motif
        })
    
    def supprimer_indisponibilite(self, jour, creneau_id):
        """
        Supprime une indisponibilité.
        """
        self.indisponibilites = [
            indispo for indispo in self.indisponibilites
            if not (indispo.get("jour") == jour and indispo.get("creneau_id") == creneau_id)
        ]
    
    def vers_dict(self):
        """
        Convertit l'enseignant en dictionnaire pour la sauvegarde JSON.
        """
        return {
            "id": self.id,
            "utilisateur_id": self.utilisateur_id,
            "specialisation": self.specialisation,
            "modules": self.modules,
            "indisponibilites": self.indisponibilites
        }
    
    @classmethod
    def depuis_dict(cls, data):
        """
        Crée un enseignant à partir d'un dictionnaire.
        """
        return cls(
            id=data.get("id"),
            utilisateur_id=data.get("utilisateur_id"),
            specialisation=data.get("specialisation", ""),
            modules=data.get("modules", []),
            indisponibilites=data.get("indisponibilites", [])
        )
    
    def __repr__(self):
        return "Enseignant(id=" + str(self.id) + ", specialisation=" + str(self.specialisation) + ")"
