# -*- coding: utf-8 -*-
"""
Classe Groupe - Représente un groupe d'étudiants
"""


class Groupe:
    """
    Classe représentant un groupe d'étudiants.
    """
    
    def __init__(self, id, nom, filiere_id, nombre_etudiants=0):
        """
        Initialise un nouveau groupe.
        """
        self.id = id
        self.nom = nom
        self.filiere_id = filiere_id
        self.nombre_etudiants = nombre_etudiants
    
    def vers_dict(self):
        """Convertit le groupe en dictionnaire."""
        return {
            "id": self.id,
            "nom": self.nom,
            "filiere_id": self.filiere_id,
            "nombre_etudiants": self.nombre_etudiants
        }
    
    @classmethod
    def depuis_dict(cls, data):
        """Crée un groupe à partir d'un dictionnaire."""
        return cls(
            id=data.get("id"),
            nom=data.get("nom"),
            filiere_id=data.get("filiere_id"),
            nombre_etudiants=data.get("nombre_etudiants", 0)
        )
    
    def __repr__(self):
        return "Groupe(id=" + str(self.id) + ", nom=" + str(self.nom) + ")"
