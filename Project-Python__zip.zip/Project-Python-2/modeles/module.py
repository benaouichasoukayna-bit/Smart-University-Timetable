# -*- coding: utf-8 -*-
"""
Classe Module - Représente un module/cours
"""


class Module:
    """
    Classe représentant un module de cours.
    """
    
    TYPES_SEANCE = ["CM", "TD", "TP"]
    
    def __init__(self, id, nom, type_seance, heures_semaine, enseignant_id,
                 filiere_id, equipements_requis=None):
        """
        Initialise un nouveau module.
        """
        self.id = id
        self.nom = nom
        self.type_seance = type_seance
        self.heures_semaine = heures_semaine
        self.enseignant_id = enseignant_id
        self.filiere_id = filiere_id
        self.equipements_requis = equipements_requis or []
    
    @property
    def type_salle_requis(self):
        """Retourne le type de salle requis selon le type de séance."""
        if self.type_seance == "CM":
            return "amphi"
        elif self.type_seance == "TP":
            return "tp"
        else:
            return "td"
    
    def vers_dict(self):
        """Convertit le module en dictionnaire."""
        return {
            "id": self.id,
            "nom": self.nom,
            "type_seance": self.type_seance,
            "heures_semaine": self.heures_semaine,
            "enseignant_id": self.enseignant_id,
            "filiere_id": self.filiere_id,
            "equipements_requis": self.equipements_requis
        }
    
    @classmethod
    def depuis_dict(cls, data):
        """Crée un module à partir d'un dictionnaire."""
        return cls(
            id=data.get("id"),
            nom=data.get("nom"),
            type_seance=data.get("type_seance"),
            heures_semaine=data.get("heures_semaine", 2),
            enseignant_id=data.get("enseignant_id"),
            filiere_id=data.get("filiere_id"),
            equipements_requis=data.get("equipements_requis", [])
        )
    
    def __repr__(self):
        return "Module(id=" + str(self.id) + ", nom=" + str(self.nom) + ")"
