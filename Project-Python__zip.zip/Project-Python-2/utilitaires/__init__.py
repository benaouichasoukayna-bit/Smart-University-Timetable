# -*- coding: utf-8 -*-
"""
Module utilitaires - Fonctions et constantes utilitaires
"""

from utilitaires.constantes import *

__all__ = [
    'JOURS_SEMAINE',
    'COULEURS',
    'TYPES_SALLES',
    'TYPES_SEANCES',
    'NIVEAUX'
]
